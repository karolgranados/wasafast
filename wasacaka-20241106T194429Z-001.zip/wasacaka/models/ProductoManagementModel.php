<?php
class ProductoManagementModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function createProducto($productoData) {
        $descrip_producto = $productoData['descrip_producto'];
        $precio_producto = $productoData['precio_producto'];
        $categoria_producto = $productoData['categoria_producto'];
        $created_at = date('Y-m-d H:i:s');

        $query = "INSERT INTO productos (descrip_producto, precio_producto, categoria_producto, created_at) 
                  VALUES (:descrip_producto, :precio_producto, :categoria_producto, :created_at)";
        
        try {
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':descrip_producto', $descrip_producto);
            $stmt->bindParam(':precio_producto', $precio_producto);
            $stmt->bindParam(':categoria_producto', $categoria_producto);
            $stmt->bindParam(':created_at', $created_at);
            
            $stmt->execute();
            return $this->db->lastInsertId();
        } catch(PDOException $e) {
            // Aquí podrías loguear el error
            return false;
        }
    }

    public function getAllProductos() {
        $query = "SELECT id_producto, descrip_producto, precio_producto, categoria_producto 
                  FROM productos ORDER BY id_producto";
        
        try {
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            // Aquí podrías loguear el error
            return false;
        }
    }

    public function getProductoById($id) {
        $query = "SELECT * FROM productos WHERE id_producto = :id";
        try {
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            return false;
        }
    }

    public function updateProducto($productoData) {
        $query = "UPDATE productos SET descrip_producto = :descrip_producto, 
                  precio_producto = :precio_producto, categoria_producto = :categoria_producto 
                  WHERE id_producto = :id";
        try {
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $productoData['id_producto'], PDO::PARAM_INT);
            $stmt->bindParam(':descrip_producto', $productoData['descrip_producto']);
            $stmt->bindParam(':precio_producto', $productoData['precio_producto']);
            $stmt->bindParam(':categoria_producto', $productoData['categoria_producto']);
            return $stmt->execute();
        } catch(PDOException $e) {
            return false;
        }
    }

    public function deleteProducto($id) {
        $query = "DELETE FROM productos WHERE id_producto = :id";
        try {
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            return $stmt->execute();
        } catch(PDOException $e) {
            return false;
        }
    }
}
