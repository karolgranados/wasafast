<?php
class ProductoManagementController {
    private $model;

    public function __construct($model) {
        $this->model = $model;
    }

    public function createProducto($productoData) {
        // Validación básica
        if (empty($productoData['first_name']) || empty($productoData['last_name']) || empty($productoData['email']) || empty($productoData['password']) || empty($productoData['role'])) {
            return ['success' => false, 'message' => 'Todos los campos son obligatorios.'];
        }

        // Validar el email
        if (!filter_var($productoData['email'], FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'El email no es válido.'];
        }

        // Validar el rol
        if (!in_array($productoData['role'], [1, 2])) {
            return ['success' => false, 'message' => 'El rol seleccionado no es válido.'];
        }

        // Intentar crear el producto
        $result = $this->model->createProducto($productoData);

        if ($result) {
            return ['success' => true, 'message' => 'Producto creado con éxito.', 'producto_id' => $result];
        } else {
            return ['success' => false, 'message' => 'Error al crear el producto. Por favor, inténtelo de nuevo.'];
        }
    }

    public function updateProducto($productoData) {
        // Validación básica
        if (empty($productoData['first_name']) || empty($productoData['last_name']) || empty($productoData['email']) || empty($productoData['role'])) {
            return ['success' => false, 'message' => 'Todos los campos son obligatorios.'];
        }

        // Validar el email
        if (!filter_var($productoData['email'], FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'El email no es válido.'];
        }

        // Validar el rol
        if (!in_array($productoData['role'], [1, 2])) {
            return ['success' => false, 'message' => 'El rol seleccionado no es válido.'];
        }

        $result = $this->model->updateProducto($productoData);
        if ($result) {
            return ['success' => true, 'message' => 'Producto actualizado con éxito.'];
        } else {
            return ['success' => false, 'message' => 'Error al actualizar el producto.'];
        }
    }

    public function deleteProducto($id) {
        $result = $this->model->deleteProducto($id);
        if ($result) {
            return ['success' => true, 'message' => 'Producto eliminado con éxito.'];
        } else {
            return ['success' => false, 'message' => 'Error al eliminar el producto.'];
        }
    }
}

