<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nosotros - Nuestro Restaurante</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #343a40;
            margin: 0;
            padding: 0;
        }

        .hero {

            background-size: cover;
            background-position: center;
            padding: 100px 0;
            text-align: center;
            color: black;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .hero p {
            font-size: 1.25rem;
            margin-bottom: 40px;
        }

        .section-title {
            font-size: 1.5rem;
            margin-bottom: 30px;
            font-weight: bold;
        }

        .about-section {
            padding: 50px 0;
        }

        .about-text {
            font-size: 1.15rem;
            line-height: 1.6;
            margin-bottom: 25px;
        }

        .about-image {
            max-width: 100%;
            border-radius: 8px;
        }

        .team-section {
            background-color: #ffffff;
            padding: 50px 0;
        }

        .team-member {
            margin-bottom: 30px;
            text-align: center;
        }

        .team-member img {
            border-radius: 50%;
            max-width: 150px;
            margin-bottom: 15px;
        }

        .team-member h4 {
            font-size: 1.25rem;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .team-member p {
            font-size: 1rem;
            color: #6c757d;
        }

        .footer {
            background-color: #343a40;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
    </style>
</head>
<body>

<?php include "../layout/header.php"; ?>

    <header class="hero">
        <h1>Bienvenidos a Nuestro Restaurante</h1>
        <p>Donde la pasión por la cocina se encuentra con la excelencia en el servicio.</p>
    </header>

    <section class="about-section container">
        <div class="row">
            <div class="col-md-6">
                <img src="//localhost/wasacaka/views/img/nosotros.jpg" alt="Sobre Nosotros" class="about-image">
            </div>
            <div class="col-md-6">
                <h2 class="section-title">Nuestra Historia</h2>
                <p class="about-text">"Wasacaka Donde Yoe" fue creado el 18 de marzo de 2018 por Yoimer Ramírez, un apasionado de la cocina originario de Magdalena, Colombia, que vivió varios años en Maracaibo, Venezuela. Inspirado por los recuerdos de su madre cocinando con dedicación y por los sabores únicos de ambas regiones, Yoimer decidió mezclar lo mejor de Colombia y Venezuela en su restaurante. Así nació Wasacaka, una creación que captura la esencia de estos dos países hermanos.</p>
                <p class="about-text"> En nuestro restaurante, nos enorgullece ofrecer una experiencia culinaria auténtica que combina tradición, innovación y el cálido espíritu de nuestras raíces. Cada plato es una celebración de la herencia culinaria que nos define, y estamos comprometidos en brindarte una experiencia que te haga sentir como en casa..</p>
            </div>
        </div>
    </section>

    <section class="team-section container">
        <h2 class="section-title text-center">Nuestro Equipo</h2>

        <br>
        <br>
        <div class="row">
            <div class="col-md-4 team-member">
                <h4>Yoimer Ramirez</h4>
                <p>Jefe</p>
            </div>
            <div class="col-md-4 team-member">
                <h4>Angie Pulgar</h4>
                <p>Gerente General</p>
            </div>
            <div class="col-md-4 team-member">
                <h4>Yulieth </h4>
                <p>Cocinera</p>
            </div>
        </div>
    </section>

    <?php include "../layout/footer.php"; ?>

</body>
</html>
